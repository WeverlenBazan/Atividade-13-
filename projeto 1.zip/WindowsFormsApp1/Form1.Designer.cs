﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.btnnome = new System.Windows.Forms.Label();
            this.btnpreço = new System.Windows.Forms.Label();
            this.btnsalvar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(232, 128);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(267, 20);
            this.txtNome.TabIndex = 0;
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(232, 202);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(267, 20);
            this.txtPreco.TabIndex = 1;
            // 
            // btnnome
            // 
            this.btnnome.AutoSize = true;
            this.btnnome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btnnome.Location = new System.Drawing.Point(151, 126);
            this.btnnome.Name = "btnnome";
            this.btnnome.Size = new System.Drawing.Size(50, 20);
            this.btnnome.TabIndex = 2;
            this.btnnome.Text = "nome";
            // 
            // btnpreço
            // 
            this.btnpreço.AutoSize = true;
            this.btnpreço.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnpreço.Location = new System.Drawing.Point(150, 202);
            this.btnpreço.Name = "btnpreço";
            this.btnpreço.Size = new System.Drawing.Size(66, 25);
            this.btnpreço.TabIndex = 3;
            this.btnpreço.Text = "preço";
            // 
            // btnsalvar
            // 
            this.btnsalvar.Location = new System.Drawing.Point(324, 284);
            this.btnsalvar.Name = "btnsalvar";
            this.btnsalvar.Size = new System.Drawing.Size(75, 23);
            this.btnsalvar.TabIndex = 4;
            this.btnsalvar.Text = "Salvar";
            this.btnsalvar.UseVisualStyleBackColor = true;
            this.btnsalvar.Click += new System.EventHandler(this.btnsalvar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsalvar);
            this.Controls.Add(this.btnpreço);
            this.Controls.Add(this.btnnome);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.txtNome);
            this.Name = "Form1";
            this.Text = "nome";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label btnnome;
        private System.Windows.Forms.Label btnpreço;
        private System.Windows.Forms.Button btnsalvar;
    }
}

